"use strict";
exports.id = 603;
exports.ids = [603];
exports.modules = {

/***/ 5444:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Instagram.20ef5ca6.png","height":36,"width":37,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAqElEQVR42i3Ouw3CQAyAYTcoBT1B0NGBBCUFI8AGsAFcJmASKrogQngmiEfFSEhJWiu/oys+n+/OtixaRiO8GoVLtIhS8gt5TD4Qwp2HOacg1L9raenGvO0p2tljTiJY8fHl44otJkiFcEAXT602AWdI05HiNvlZCDGXPmfmJwU2lXsPiRAeEKzxxgdLmgS52GjM/JLW1fGTFhScrGCKH25g80ZGbgsPa1vJslNMDq3rAAAAAElFTkSuQmCC"});

/***/ }),

/***/ 3257:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Logo.f1664d42.svg","height":47,"width":74});

/***/ }),

/***/ 9072:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/close.341de0d1.png","height":297,"width":297,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAS1BMVEX+9G3+9G3+9G3+9G3+9Gz+823+9G3+9G3+823+82z+82z+9G3+9G3+9G3+9Gz+823+9G3+9Gz+82z+9G3+823+9G3+9Gz+823+82xjJCCpAAAAFXRSTlMADxApKSkxM7i4ury/wsLC7e3t+PiqOO8xAAAAQ0lEQVR42g3LQQKAIAgF0a+YlkpagnH/k8asZvMA4iVMAE3zJoE1n1fWAdk9hG7Lp8ZYTTB2aa18jONVM30SnMu6E351wwNKnpFyaQAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 4561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/menu.eec6fb23.png","height":297,"width":297,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAhFBMVEX+9G3+9Gz+9G3+823+823+823+9G3+823+823+9G3+9G3+9G3+823+823+9G3+9G3+9G3+9Gz+823+9G3+9G3+9G3+9G3+9G3+9G3+9G3+9G3+823+823+823+9G3+9G3+82z+9G3+9G3+9Gz+9G3+823+9G3+823+823+9G3+823+82z7cR/bAAAAKXRSTlMAKCkqVFZcXWBkZmhsbnF7jr6+wMHCycrX2Nnb4ufr7Ozt7vL39/v7/EZP1JAAAABGSURBVHjaBUAFEoAgEFzOxBa7W+H4//8cgJr3qwmgk7W2B6Fb3NCbrAL3QZrkswFvhYz9gaHsGGVybeHshpkvAVD13KXAD8WYBXqJ/QQ6AAAAAElFTkSuQmCC"});

/***/ }),

/***/ 3731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./public/images/Instagram.png
var Instagram = __webpack_require__(5444);
;// CONCATENATED MODULE: ./public/images/LinkedIn.png
/* harmony default export */ const LinkedIn = ({"src":"/_next/static/media/LinkedIn.0a27ccac.png","height":36,"width":36,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAq0lEQVR42jWPOw4BURiF/11oRCI6liBRWgELoL6TaMQWtBZBpZGg0ChsQCe6KTTccu4UHrnjO5lH8uU8/jOTjOmJwTVgH0Pi0Re6g3Z5zBIdbxR3/DdmrhDkB7mjwQZUTMHLQ6hGJw2emDcsYMnXBnR9fAqFBh6To0PeGqEr8pjhmqyB22rJYQIzOJDn9Bf81Vg2CWk1+qA/VN7T9+rfbHE4UgbI8We0a2b2B6wRtw7MZMsbAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/images/Twitter.png
/* harmony default export */ const Twitter = ({"src":"/_next/static/media/Twitter.5704347d.png","height":36,"width":35,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAlklEQVR42k2MPQrCQBCFBwSx8R4iaGErtp7AQ1jsdKIXsPEIdjYeRyy9hpCkyN8m3yS7SQY+5s17j5E4PnXzUevOZ7roj0SvGOtJ+IYGfvCwwgtR8uHGPvnEEQKb7GKFe29qwFV4Hl3Bxl6u4G8lKAnzoL8SB/OMkYcPoFY4xHAPT4wCavQHupB7ZoUlwkpH9laYIRSRFubOlcp4Sw3cAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/Footer/index.tsx






const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex w-full justify-center items-center flex-col pb-[60px]",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "text-yellow text-[24px] text-center font-semibold",
                    children: "Looking Beyond The Vision"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-row justify-center items-center pt-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "px-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.instagram.com/beyondvisionltd/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: Instagram/* default */.Z,
                                    alt: "social"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "px-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.linkedin.com/company/beyond-vision-ltd/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: LinkedIn,
                                    alt: "social"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "px-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://twitter.com/BeyondVisionLTD",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: Twitter,
                                    alt: "social"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "text-yellow opacity-50 pt-1 font-regular text-[16px]",
                    children: "\xa9 2022 by Beyond Vision"
                })
            ]
        })
    });
};
/* harmony default export */ const components_Footer = (Footer);


/***/ }),

/***/ 1672:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _public_images_Logo_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3257);
/* harmony import */ var _public_images_menu_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4561);
/* harmony import */ var _public_images_close_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9072);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_8__]);
framer_motion__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const NavBar = ()=>{
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const variants = {
        open: {
            opacity: 1
        },
        closed: {
            opacity: 0
        }
    };
    if (isOpen === true) {
        window.scrollTo(0, 0);
    }
    const links = {
        home: "/",
        about: "/about-us",
        team: "/meet-the-team",
        clients: "/our-talents",
        contact: "/contact"
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
            className: "relative z-[9999] w-full",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `ml-[40px] xs:ml-[75px] mt-[50px] absolute z-50 ${isOpen ? "fixed" : ""}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: _public_images_Logo_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                        // layout="responsive"
                        height: 45,
                        width: 73,
                        alt: "logo"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: "absolute list-none right-0 mr-[75px] pt-[38px] hidden bml:block",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: `inline-block p-5 text-[20px] nav-item text-white ${router.pathname !== links.home ? "text-text" : "text-[#FFF46D] underline "}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: `inline-block p-5 text-[20px] nav-item text-white ${router.pathname !== links.about ? "text-text" : "text-[#FFF46D] underline "}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/about-us",
                                children: "About us"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: `inline-block p-5 text-[20px] nav-item text-white ${router.pathname !== links.team ? "text-text" : "text-[#FFF46D] underline "}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/meet-the-team",
                                children: "Meet the team"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: `inline-block p-5 text-[20px] nav-item text-white ${router.pathname !== links.clients ? "text-text" : "text-[#FFF46D] underline "}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/our-talents",
                                children: "Our talents"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: `inline-block p-5 text-[20px] nav-item text-white ${router.pathname !== links.contact ? "text-text" : "text-[#FFF46D] underline "}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/contact",
                                children: "Contact us"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.button, {
                    onClick: ()=>setIsOpen(!isOpen)
                    ,
                    className: ` z-[60] cursor-pointer right-0 mr-[40px] xs:mr-[75px] top-[45px] block bml:hidden select-none ${isOpen ? "fixed" : "absolute"}`,
                    children: !isOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        width: 40,
                        height: 40,
                        src: _public_images_menu_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                        alt: "menuicon"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        width: 40,
                        height: 40,
                        src: _public_images_close_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                        alt: "menuicon"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.AnimatePresence, {
                    exitBeforeEnter: true,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.div, {
                        animate: isOpen ? "open" : "closed",
                        variants: variants,
                        exit: {
                            opacity: 0
                        },
                        transition: {
                            duration: 0.3
                        },
                        className: `z-50 fixed bg-background opacity-100 md:opacity-0 w-screen h-screen flex justify-center items-center overflow-hidden md:hidden ${isOpen ? "block" : "hidden"}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `ml-[40px] xs:ml-[75px] mt-[50px]  absolute z-50 top-0 left-0`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: _public_images_Logo_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                    // layout="responsive"
                                    height: 45,
                                    width: 73,
                                    alt: "logo"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "flex justify-center items-center w-full h-full flex-col bml:hidden",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: `text-center p-2 text-[20px] nav-item text-white ${router.pathname !== links.home ? "text-text" : "text-[#FFF46D] underline "}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/",
                                            children: "Home"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: `text-center p-2 text-[20px] nav-item text-white ${router.pathname !== links.about ? "text-text" : "text-[#FFF46D] underline "}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/about-us",
                                            children: "About us"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: `text-center p-2 text-[20px] nav-item text-white ${router.pathname !== links.team ? "text-text" : "text-[#FFF46D] underline "}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/meet-the-team",
                                            children: "Meet the team"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: `text-center p-2 text-[20px] nav-item text-white ${router.pathname !== links.clients ? "text-text" : "text-[#FFF46D] underline "}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/our-talents",
                                            children: "Our talents"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: `text-center p-2 text-[20px] nav-item text-white ${router.pathname !== links.contact ? "text-text" : "text-[#FFF46D] underline "}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/contact",
                                            children: "Contact us"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavBar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5603:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3731);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1672);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Navbar__WEBPACK_IMPORTED_MODULE_4__]);
_Navbar__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Layout = ({ children , title  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-[#161616] -z-50",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "shortcut icon",
                        type: "image/jpeg",
                        href: "/favicon.jpg"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        httpEquiv: "X-UA-Compatible",
                        content: "IE=edge"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1.0"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Beyond Vision LTD is an influencer marketing and management agency based out of the United Kingdom, but not limited to working inside of the United Kingdom as the agency works with various influencers & companies of all different calibers all around the globe."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        content: "#FFF46D",
                        "data-react-helmet": "true",
                        name: "theme-color"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:url",
                        content: "https://www.beyondvisionltd.org"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:type",
                        content: "website"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: "Beyond Vision LTD"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: "Beyond Vision LTD is an influencer marketing and management agency based out of the United Kingdom, but not limited to working inside of the United Kingdom as the agency works with various influencers & companies of all different calibers all around the globe."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image",
                        content: "https://i.imgur.com/Gd1N9JI.jpg"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:card",
                        content: "summary_large_image"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "twitter:domain",
                        content: "www.beyondvisionltd.org"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "twitter:url",
                        content: "https://www.beyondvisionltd.org"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:title",
                        content: "Beyond Vision LTD"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:description",
                        content: "Beyond Vision LTD is an influencer marketing and management agency based out of the United Kingdom, but not limited to working inside of the United Kingdom as the agency works with various influencers & companies of all different calibers all around the globe."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:image",
                        content: "https://i.imgur.com/Gd1N9JI.jpg"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Navbar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;